#!/bin/bash

# Check args
if [ "$#" -lt 2 ]; then
    echo "Usage: ./runbf.sh <interpreter.bf> <program.bf> [input_file]"
    exit 1
fi

INTERPRETER="$1"
PROGRAM="$2"
INPUT_FILE="$3"

if [ -z "$INPUT_FILE" ]; then
    python3 run_nested_bf.py "$INTERPRETER" "$PROGRAM"
else
    python3 run_nested_bf.py "$INTERPRETER" "$PROGRAM" < "$INPUT_FILE"
fi

