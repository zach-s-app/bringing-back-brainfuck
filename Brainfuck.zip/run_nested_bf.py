import sys

def bf_interpret(code, input_data=''):
    tape = [0] * 30000
    ptr = 0
    ip = 0
    input_ptr = 0
    output = []
    jump_map = {}
    stack = []

    # Precompute jump map
    for i, c in enumerate(code):
        if c == '[':
            stack.append(i)
        elif c == ']':
            start = stack.pop()
            jump_map[start] = i
            jump_map[i] = start

    while ip < len(code):
        cmd = code[ip]
        if cmd == '>':
            ptr += 1
            if ptr == len(tape): tape.append(0)
        elif cmd == '<':
            ptr -= 1
        elif cmd == '+':
            tape[ptr] = (tape[ptr] + 1) & 0xFF
        elif cmd == '-':
            tape[ptr] = (tape[ptr] - 1) & 0xFF
        elif cmd == '.':
            output.append(chr(tape[ptr]))
        elif cmd == ',':
            if input_ptr < len(input_data):
                tape[ptr] = ord(input_data[input_ptr])
                input_ptr += 1
            else:
                tape[ptr] = 0  # simulate EOF with zero
        elif cmd == '[' and tape[ptr] == 0:
            ip = jump_map[ip]
        elif cmd == ']' and tape[ptr] != 0:
            ip = jump_map[ip]
        ip += 1
    return ''.join(output)

def read_file(filename):
    with open(filename, 'r') as f:
        return ''.join(filter(lambda c: c in '><+-.,[]', f.read()))

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 run_nested_bf.py <interpreter.bf> <program.bf>")
        sys.exit(1)

    # Load BF interpreter in BF
    interp_code = read_file(sys.argv[1])

    # Load BF program (to be interpreted by the interpreter)
    program_code = read_file(sys.argv[2])

    # Optional input from stdin (like < file)
    user_input = ''
    if not sys.stdin.isatty():
        user_input = sys.stdin.read()

    # Combine: program_code + user_input, separated by newline if input exists
    inner_input = program_code + ('\n' + user_input if user_input else '')

    # Run the outer interpreter with the BF interpreter code and inner input
    result = bf_interpret(interp_code, input_data=inner_input)

    # Show output from nested program
    print(result, end='')

